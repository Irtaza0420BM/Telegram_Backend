import { IsEmail, IsNotEmpty ,IsString, Length, IsOptional, IsAlphanumeric} from 'class-validator';

// export class CreateAdminDto {
//   @IsEmail()
//   @IsNotEmpty()
//   email: string;


//   @IsString()
//   @IsNotEmpty()
//   @Length(5,20)
//   username: string;

//   @IsAlphanumeric()
//   @IsNotEmpty()
//   @Length(8,20)
//   password: string;
// }


export class AdminSignupDto {
    @IsEmail() email: string;
    @Length(5,20) username: string;
    @Length(6,20) password: string;
  }
  
  export class AdminLoginDto {
    @IsEmail() email: string;
    @Length(6,20) password: string;
  }
  